export interface LoginRequestProps {
    username: string;
    password: string | number;
}
