import request from '@/utils/request'
import { LoginRequestProps } from './requestProps'
export function Login (params: LoginRequestProps) {
  return request({
    url: '/login',
    method: 'post',
    data:params
  })
}
