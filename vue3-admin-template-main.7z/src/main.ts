import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementPlus from 'element-plus'
import globalComponents from '@/components/index'
import './assets/style/index.scss'
import 'element-plus/lib/theme-chalk/index.css'
import '../indexDB'
// VUE_APP_MOCK的值为true，并且在开发环境下
if (process.env.VUE_APP_MOCK && process.env.NODE_ENV === 'development') {
  require("../mock");
}

createApp(App)
  .use(store)
  .use(router)
  .use(globalComponents)
  .use(ElementPlus)
  .mount('#app')
