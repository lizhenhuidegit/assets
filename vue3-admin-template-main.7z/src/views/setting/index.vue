<template>
  <div class="home">
    setting
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'Setting',
  components: {
  }
})
</script>
