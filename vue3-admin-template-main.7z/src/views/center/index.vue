<template>
  <div>
    center
    <my-header/>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'Center',
  components: {
  }
})
</script>
