<template>
  <div class="">
    about : <input type="text">
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'About',
  components: {
  }
})
</script>
