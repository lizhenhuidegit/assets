<template>
  <div class="home">
    <input type="text">
    <div class="e-box" style="height: 600px" id="myChart"></div>
  </div>
</template>

<script lang="ts">
import { defineComponent, onMounted } from 'vue'
import * as echarts from 'echarts'
export default defineComponent({
  name: 'Home',
  setup () {
 
  },
  components: {}
})
</script>
<style lang="scss">
.home {
  box-sizing: border-box;
  border: 1px solid yellow;
}
</style>
