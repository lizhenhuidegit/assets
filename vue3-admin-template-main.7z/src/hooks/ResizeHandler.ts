import { onMounted, onUnmounted, ref, Ref } from 'vue'

const ResizeHandler = (): Ref<string> => {
  const _h = ref('100%')
  const setHeight = (): void => { _h.value = document.documentElement.clientHeight - 100 + 'px' }
  setHeight()
  onMounted(() => window.addEventListener('resize', setHeight))
  onUnmounted(() => window.removeEventListener('resize', setHeight))
  return _h
}
export default ResizeHandler
