<template>
    <div class="main-content scrollbar-bar" :style="{'height':Mheight}">
      <router-view v-slot="{ Component }">
        <keep-alive :include="keepAlive">
          <component :is="Component" />
        </keep-alive>
      </router-view>
    </div>
</template>
<script lang="ts">
import {useStore} from 'vuex'
import { defineComponent, Ref ,computed} from 'vue'
import ResizeHandler from '@/hooks/ResizeHandler'
export default defineComponent({
  name: 'appmain',
  setup () {
    const store = useStore();
    const Mheight: Ref<string> = ResizeHandler();
    const keepAlive = computed(() => store.state.app.keepAlive);
    return {
      Mheight,
      keepAlive
    }
  }
})
</script>
<style lang="scss" scoped>
  .main-content{
    box-sizing: border-box;
    padding: 10px;
    overflow-y: auto;
    overflow-x: hidden;
  }
</style>
