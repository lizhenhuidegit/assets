<template>
    <div>Header Component</div>
</template>
<script>
import { defineComponent } from 'vue'
export default defineComponent({
  name: 'my-header'
})
</script>
