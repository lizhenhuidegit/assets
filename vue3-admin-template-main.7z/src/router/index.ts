import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router'
import { useBeforeAuthen } from '@/hooks/usAuthen'
const LayOut = () => import(`@/layout/index.vue`);
const _component = (file: string) => import(`@/views/${file}/index.vue`);

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    component: LayOut,
    redirect: '/',
    meta: {
      title: '模块一',
      icon: 'el-icon-location'
    },
    children: [
      {
        name: 'Home',
        path: '/',
        component: _component('home'),
        meta: {
          title: '首页',
          hidden: false
        }
      },
      {
        name: 'Center',
        path: '/center',
        component: _component('center'),
        meta: {
          title: '个人中心'

        }
      }
    ]
  },
  {
    path: '/outher',
    component: LayOut,
    meta: {
      title: '模块二',
      icon: 'el-icon-platform-eleme',
      hidden: false,
      iconStyle: {
        color: 'yellow'
      }
    },
    redirect: 'outher/setting',
    children: [
      {
        name: 'Setting',
        path: '/outher/setting',
        component: _component('setting'),
        meta: {
          title: '设置',
          hidden: false
        }
      },
      {
        name: 'About',
        path: '/outher/about',
        component: _component('about'),
        meta: {
          title: '关于',
          hiddenTag: false
        }
      }
    ]
  },
  {
    path: '/login',
    name: 'Login',
    meta: {
      hidden: true,
      title: '登录'
    },
    component: _component('login')
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})
router.beforeEach((to, from, next) => useBeforeAuthen(to, from, next))

export default router
