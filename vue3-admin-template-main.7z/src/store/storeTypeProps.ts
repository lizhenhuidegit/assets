export interface tagsProps {
    title: string;
    path: string;
    name: string;
    params?: Record<string, any>;
    query?: Record<string, any>;
  }
export interface stateProps {
    isOpen?: boolean;
    tags: Array<tagsProps>;
    keepAlive: Array<string>;
  }
