import { tagsProps, stateProps } from '../storeTypeProps'
const sessionTags = window.sessionStorage.getItem('tags');
const keepAlive = window.sessionStorage.getItem('keepAlive');
export default {
  namespaced: true,
  state: {
    isOpen: true,
    tags: sessionTags ? [...JSON.parse(sessionTags)] : [{ title: '首页', path: '/' }],
    keepAlive: keepAlive?[...JSON.parse(keepAlive)]:['Home'],
  },
  mutations: {
    SET_OPEN (state: stateProps) {
      state.isOpen = !state.isOpen
    },
    PUSH_TAG (state: stateProps, tag: tagsProps) {
      const isTag = state.tags.findIndex((t: tagsProps) => t.path === tag.path) > -1
      if (isTag || tag.path === '/home') return
      state.tags.push(tag)
      window.sessionStorage.setItem('tags', JSON.stringify(state.tags))
    },
    DELETE_TAG (state: stateProps, tag: tagsProps) {
      const dTagIndex = state.tags.findIndex((t: tagsProps) => t.path === tag.path)
      if (dTagIndex > -1) {
        state.tags.splice(dTagIndex, 1);
        window.sessionStorage.setItem('tags', JSON.stringify(state.tags))
      }
    },
    ADD_ALIVE (state: stateProps, name: string){
      if(state.keepAlive.indexOf(name) == -1){
        state.keepAlive.push(name);
        window.sessionStorage.setItem('keepAlive', JSON.stringify(state.keepAlive))
      }
    },
    DELETE_ALIVE (state: stateProps, name: string){
      let index:number = state.keepAlive.indexOf(name);
      if(index != -1){
        state.keepAlive.splice(index,1);
        window.sessionStorage.setItem('keepAlive', JSON.stringify(state.keepAlive))
      }
    }
  },
  actions: {
  }
}
