export default {
  url: '/login',
  type: 'post',
  response(){
    return {
      code: '200',
      data: {
        name: 'admin',
        token: '123654789',
      }
    }
  }
}