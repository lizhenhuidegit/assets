export default {
  url: '/product/list',
  type: 'get',
  response(){
    return {
      code: '200',
      data: {
        list: [1,2,3]
      }
    }
  }
}