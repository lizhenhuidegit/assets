// index.js
const Mock = require('mockjs');
const mockFiles = require.context('./modules', true, /\.ts$/);
let mocks:Array<any> = [];

mockFiles.keys().forEach(key => {
  mocks.push(mockFiles(key).default);
});
mocks.forEach((item:any) => {
  Mock.mock(new RegExp(`${process.env.VUE_APP_BASE_API+item.url}`), item.type, item.response)
})

