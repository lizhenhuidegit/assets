/**
 * @property {String} tableName 表名
 * @property {Object} option indexDB建表参数
 * @property {Array} indexs 索引列表
 *   @property {String} key 字段
 *   @property {Object} option indexDB索引参数
 * @property {Object} table  表的字段
 *   @property {String} type 类型
 *   @property {any} default 默认值
 *   @property {Boolean} automatic 是否补充随机值（type为String时）
 *   @property {Boolean} required 是否必填
 *   @property {Boolean} memory 占用空间
 */
export default{
  tableName: "grade",
  option: { keyPath: "id" },
  indexs: [
    {
      key: "id",
      option:{
        unique: true
      }
    },
    {
      key: "cardNo",
      option:{
        unique: true
      }
    }
  ],
  codes:{
    id: {
      type: 'String',
      defaultValue: '',
      automatic: true,
      required: true,
      memory:5
    },
    cardNo: {
      type: 'String',
      automatic: false,
      required: true,
      defaultValue: '',
      memory:5
    },
    name: {
      type: 'String',
      automatic: false,
      required: false,
      defaultValue: '',
      memory:5
    },
    age: {
      type: 'Number',
      automatic: false,
      required: false,
      defaultValue: 0,
      memory:5
    },
  }
}
