import DB from "./DB";
const tableFiles = require.context('./table', true, /\.ts$/);
const idb = function ({ dbName, version = new Date().getTime(), tables = [] }) {
  const db = new DB({dbName,version});
  for (let tableItem of tables) {
    db.table.push(tableItem);
  }
  return new Promise(reslove=>{
    reslove(db)
  })
};
export default idb({
  dbName: 'appMainData',
  version: 1001,
  tables: tableFiles.keys().map(key => {
    return tableFiles(key).default;
  }) as []
}).then(res=>{
  window.myMainDb = res;
})