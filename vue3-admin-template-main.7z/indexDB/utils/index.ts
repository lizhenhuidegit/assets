export const createRes = function (msg,data:any='') {
  let status = msg === true;
  console.log(msg||'执行成功','::',data||'null');
  return {
   status,
   msg: status?'':msg,
   data
  }
};
export const DataTypes = {
  String: '[object String]',
  Array: '[object Array]',
  Object: '[object Object]',
  Number: '[object Number]',
};
export const isNone = data=>{
  return data === ''||data === undefined||data === null;
}
export const isObject = data => Object.prototype.toString.call(data) === "[object Object]";
export const isArray = data => Object.prototype.toString.call(data) === "[object Array]";
export const isNumber = data => Object.prototype.toString.call(data) === "[object Number]";
export const isString = data => Object.prototype.toString.call(data) === "[object String]";

export const checkData = function (_data,template) {
  let data = JSON.parse(JSON.stringify(_data)),
      echoData;
  let list;
  if(!isObject(template)){
    return createRes('请选择模板');
  }
  if(isObject(_data)){
    list = [data];
    echoData = [{}];
  }else if(isArray(_data)){
    list = data;
    echoData = data.map(item=>{});
  }else{
   return createRes('数据只能为数组或对象');
  }
  let nowTime = Date.now();
  for(let i = 0; i < list.length;i++){
    let item = list[i];
    for(let key in template){
      let {type,defaultValue,automatic,required,memory} = template[key];
      if(automatic && isNone(item[key]) && type === 'String'){
        item[key] = 'indexDB_'+key+'_'+i+'_'+nowTime;
      }
      if(required && isNone(item[key])){
        return createRes(`${key}不能为空`);
      }
      item[key] = (item[key]===''||item[key] === undefined)?defaultValue:item[key];
      if(DataTypes[type] != Object.prototype.toString.call(item[key])){
        return createRes(`${key}类型为${type}`);
      }
      echoData[i][key] = item[key];
    }
  }
  return createRes(true,echoData);
}
