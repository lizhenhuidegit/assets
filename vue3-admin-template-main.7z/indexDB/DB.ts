import {isObject,isArray,checkData,createRes} from './utils';
const indexedDB = window.indexedDB;
const logError = (str:any)=>{console.error(`%c${str}`,"color:red")};

class Dep {
  private deps;
  constructor() {
    this.deps = [];
  }
  add(element) {
    this.deps.push(element);
  }
  notify() {
    for (let i = 0; i < this.deps.length; i++) {
      this.deps[i]();
    }
    this.deps.length = 0;
  }
}
class DB {
  public dbName;
  public version;
  public db;
  public idb;
  public table;
  private _dep_;
  constructor({ dbName, version }) {
    this.dbName = dbName;
    this.version = version;
    this.db = null;
    this.idb = null;
    this.table = [];
    this._dep_ = new Dep();
  }
  /**
   * 打开数据库
   * @success 成功的回调，返回db，非必传
   * @error 失败的回调，返回错误信息，非必传
   * */
  open() {
    return new Promise(resolve=>{
      const request = indexedDB.open(this.dbName, this.version);
      request.onerror = (e:any) => {
        logError(e.currentTarget.error.message);
      };
      request.onsuccess = (e:any) => {
        this.db = e.target.result;
        resolve(createRes(true,this.db));
        this._dep_.notify();
      };
      request.onupgradeneeded = (e:any) => {
        this.idb = e.target.result;
        for (let i = 0; i < this.table.length; i++) {
          this._createTable(this.idb, this.table[i]);
        }
      };
    })
  }
  //  关闭数据库
  closeDB() {
    const handler = () => {
      this.db.close();
    };
    this._action(handler);
  }
  // 删除数据库
  deleteDB() {
    indexedDB.deleteDatabase(this.dbName);
  }
  //清空某张表的数据
  clearTable({ tableName }) {
    this._action(() =>
      this._createTransaction(tableName, "readwrite").clear()
    );
  }
  /**
   * @method 查询某张表的所有数据
   * @param {Object}
   *   @property {String} tableName 表名
   *   @property {Function} [success] @return {Array} 查询成功的回调，返回查到的结果
   * */
  queryAll({ tableName}) {  
    return new Promise((resolve)=>{
      const handler = () => {
        const res:Array<any> = [];
        this._createTransaction(
          tableName,
          "readonly"
        ).openCursor().onsuccess = e =>
          this._cursorSuccess(e, {
            condition: () => true,
            handler: ({currentValue}) => res.push(currentValue),
            over: () => resolve(createRes(true,res))
          });
      };
      this._action(handler);
    }) 
  }

  /**
   * @method 查询
   * @param {Object}
   *   @property {String} tableName 表名
   *   @property {Function} condition 查询的条件
   *      @arg {Object} 遍历每条数据，和filter类似
   *      @return 条件
   *   @property {Function} [success] @return {Array} 查询成功的回调，返回查到的结果
   * */
  query({ tableName, condition}) {
    if (typeof condition !== "function") {
      logError("condition必须是一个函数");
      return;
    }
    return new Promise((resolve)=>{
      const handler = () => {
        let res:Array<any> = [];
        this._createTransaction(
          tableName,
          "readonly"
        ).openCursor().onsuccess = e =>
          this._cursorSuccess(e, {
            condition,
            handler: ({ currentValue }) => res.push(currentValue),
            over: () => resolve(createRes(true,res))
          });
      };
      this._action(handler);
    }) 
  }

  /**
   * @method 增加数据
   * @param {Object}
   *   @property {String} tableName 表名
   *   @property {Object} data 插入的数据
   *   @property {Function} [success] 插入成功的回调
   * */
  insert({ tableName, data}) {
    const keyName = this._getKeyName(tableName);
    if(isArray(data)){
      data.forEach(d=>{
        d[keyName] = '';
      })
    }else if(isObject(data)){
      data[keyName] = '';
    }
    return new Promise(resolve=>{
      let nowData = checkData(data,this._getTemplate(tableName));
      if(!nowData.status){
        resolve(nowData)
        return;
      }
      this._action(() => {
        const store = this._createTransaction(tableName, "readwrite");
        if(isArray(nowData.data)){
          nowData.data.forEach(v => {
            store.put(v);
          });
        }else{
          store.put(nowData.data);
        }
        resolve(createRes(true,nowData.data))
      });
    })
  }
  /**
   * @method 删除数据
   * @param {Object}
   *   @property {String} tableName 表名
   *   @property {Function} condition 查询的条件，遍历，与filter类似
   *      @arg {Object} 每个元素
   *      @return 条件
   *   @property {Function} [success] 删除成功的回调  @return {Array} 返回被删除的值
   *   @property {Function} [error] 错误函数 @return {String}
   * */
  delete({ tableName, condition}) {
    return new Promise((resolve)=>{
      if (typeof condition !== "function") {
        resolve(createRes("condition必须是一个函数"))
        return;
      }  
      const handler = () => {
        let res:Array<any> = [];
        this._createTransaction(
          tableName,
          "readwrite"
        ).openCursor().onsuccess = e =>
          this._cursorSuccess(e, {
            condition,
            handler: ({ currentValue, cursor }) => {
              res.push(currentValue);
              cursor.delete();
            },
            over: () => {
              if (res.length == 0) {
                resolve(createRes("没有找到要删除的数据"))
                return;
              }
              resolve(createRes(true,res));
            }
          });
      };
      this._action(handler);
    })
  }

  /**
   * @method 删除数据(主键)
   * @param {Object}
   *   @property {String} tableName 表名
   *   @property {String\|Number} target 目标主键值
   *   @property {Function} [success] 删除成功的回调  @return {Null}
   * */
  deleteByKey({tableName,target}) {
    return new Promise((resolve)=>{
      this._action(() => {
        const request = this._createTransaction(tableName, "readwrite").delete(target);
        request.onsuccess = () => resolve(createRes(true,'删除成功'));
        request.onerror = () => resolve(createRes("删除失败"));
      });
    })
  }
  /**
   * @method 修改某条数据(主键)
   * @param {Object}
   *   @property {String} tableName 表名
   *   @property {String\|Number} target 目标主键值
   *   @property {Function} handle 处理函数，接收本条数据的引用，对其修改
   *   @property {Function} [success] 修改成功的回调   @return {Object} 返回被修改后的值
   * */
  updateByKey({ tableName, target, value }) {
    return new Promise((resolve)=>{
      this._action(() => {
        const store = this._createTransaction(tableName, "readwrite");
        store.get(target).onsuccess = e => {
          let currentValue = e.target.result;
          delete value[target];
          currentValue = {...currentValue,...value};
          let nowData = checkData(currentValue,this._getTemplate(tableName));
          if(!nowData.status){
            resolve(nowData)
            return;
          }
          store.put(currentValue);
          resolve(createRes(true,currentValue));
        };
      });
    })  
  }

  /**
   * @method 修改数据
   * @param {Object}
   *   @property {String} tableName 表名
   *   @property {Function} condition 查询的条件，遍历，与filter类似
   *      @arg {Object} 每个元素
   *      @return 条件
   *   @property {Function} handle 处理函数，接收本条数据的引用，对其修改
   *   @property {Function} [success] 修改成功的回调，返回修改成功的数据   @return {Array} 返回被修改后的值
   * */
  update({ tableName, condition,value}) {
    const keyName = this._getKeyName(tableName);
    return new Promise((resolve)=>{
      let notUpdate:any = [],msg;
      if (typeof condition !== "function") {
        resolve(createRes("condition必须是一个函数"))
        return;
      } 
      const handler = () => {
        let res:Array<any> = [];
        this._createTransaction(
          tableName,
          "readwrite"
        ).openCursor().onsuccess = e =>
          this._cursorSuccess(e, {
            condition,
            handler: ({ currentValue, cursor }) => {
              delete value[keyName];
              currentValue = {...currentValue,...value};  
              let nowData = checkData(currentValue,this._getTemplate(tableName));
              if(!nowData.status){
                notUpdate.push(value);
                msg += (nowData.msg+';')
                return;
              }
              res.push(nowData.data);
              cursor.update(nowData.data);  
            },
            over: () => {
              if (notUpdate.length != 0) {
                resolve(createRes(msg,notUpdate));
                return;
              }
              resolve(createRes(true,res));
            }
          });
      };
      this._action(handler);
    })
  }

  /**
   * @method 查询数据（主键值）
   * @param {Object}
   *   @property {String} tableName 表名
   *   @property {Number|String} target 主键值
   *   @property {Function} [success] 查询成功的回调，返回查询成功的数据   @return {Object} 返回查到的结果
   *
   * */
  queryByKey({ tableName, target}) {
    return new Promise(resolve=>{
      const handleFn = () => {
        this._createTransaction(tableName, "readonly").get(
          target
        ).onsuccess = e => {
          const result = e.target.result;
          resolve(createRes(true,result || null));
        };
      };
      this._action(handleFn);
    })
  }

  /**
   * @method 查询数据（索引）
   * @param {Object}
   *   @property {String} tableName 表名
   *   @property {Number|String} indexName 索引名
   *   @property {Number|String} target 索引值
   *   @property {Function} [success] 查询成功的回调，返回查询成功的数据   @return {Object} 返回查到的结果
   *
   * */
  queryByIndex({ tableName, indexName, target}) {
    return new Promise(resolve=>{
      const handleFn = () => {
        this._createTransaction(tableName, "readonly")
          .index(indexName)
          .get(target).onsuccess = e => {
            const result = e.target.result;
            resolve(createRes(true,result || null));
          };
      };
      this._action(handleFn);
    }) 
  }

  /**
   * @method 游标开启成功,遍历游标
   * @param {Function} 条件
   * @param {Function} 满足条件的处理方式 @arg {Object} @property cursor游标 @property currentValue当前值
   * @param {Function} 游标遍历完执行的方法
   * @return {Null}
   * */
  private _cursorSuccess(e, { condition, handler, over }) {
    const cursor = e.target.result;
    if (cursor) {
      const currentValue = cursor.value;
      if (condition(currentValue)) handler({ cursor, currentValue });
      cursor.continue();
    } else {
      over();
    }
  }
  /**
   * 
   * @param {String} tableName 
   * @returns keyPathName
   */
  private _getKeyName(tableName){
    let echo = '';
    this.table.forEach(table => {
      if(table.tableName === tableName){
        echo = table?.option.keyPath;
      }
    });
    return echo||'';
  }
  /**
   * 
   * @param {String} tableName 
   * @returns keyPathName
   */
   private _getTemplate(tableName){
    let echo;
    this.table.forEach(table => {
      if(table.tableName === tableName){
        echo = table.codes;
      }
    });
    return echo;
  }
  /**
   * @method 获取数据表
   * @param {String} 表名
   * @param {String} 权限
   * @return store
   * */
   private _createTransaction(tableName, mode = "readwrite") {
    if (!tableName || !mode) {
      throw new Error("请选择表名");
    }
    const transaction = this.db.transaction(tableName, mode);
    return transaction.objectStore(tableName);
  }

  // db是异步的,保证fn执行的时候db存在
  private _action(handler) {
    const action = () => {
      handler();
    };
    // 如果db不存在，加入依赖
    if (!this.db) {
      this._dep_.add(action);
      this.open();
    } else {
      action();
    }
  }

  /**
   * 创建table
   * @option<Object>  keyPath指定主键
   * @index 索引配置
   * */
   private _createTable(idb, { tableName, option, indexs = [] }) {
    if (!idb.objectStoreNames.contains(tableName)) {
      let store = idb.createObjectStore(tableName, option);
      for (let indexItem of indexs) {
        this._createIndex(store, indexItem);
      }
    }
  }

  /**
   * 创建索引
   * @option<Object> unique是否是唯一值
   * */
  private _createIndex(store, { key, option }) {
    store.createIndex(key, key, option);
  }
}

export default DB;